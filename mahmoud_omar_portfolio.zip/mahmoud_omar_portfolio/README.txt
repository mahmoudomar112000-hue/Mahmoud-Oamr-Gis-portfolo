Mahmoud Omar - GIS Portfolio
===========================

This is a minimal multi-page portfolio for Mahmoud Omar, ready to publish on GitHub Pages.

Files:
- index.html
- experience.html
- projects.html
- skills.html
- certificates.html
- contact.html
- style.css
- assets/ (profile & project placeholders)
- Mahmoud_Omar_CV.pdf

To publish:
1. Create a new repository on GitHub (e.g., mahmoud-omar-portfolio).
2. Upload all files and folders from this archive to the repository root.
3. In the repository settings, enable **GitHub Pages** from the main branch (or gh-pages) and use the root folder.
4. After a minute, your site will be available at: https://<your-username>.github.io/<repo-name>/

Replace placeholder images in assets/profile and assets/projects with real images (keep filenames or update the HTML paths).